public class HelloWorldCollinPaddock {
    public static void main(String[] args) {
        
        System.out.println("Hello World from Collin Paddock");
        System.out.println("This is part of lab 1");
        
    }
 }
// public class tempCodeRunnerFile{
// 	public static void main (String [] args){
// 		System.out.println("Hello World From the Command line!");
// 		System.out.println("This is: Collin Paddock");
// 	}
// } 
